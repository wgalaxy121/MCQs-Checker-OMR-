<?php


$db = mysqli_connect("localhost","root","") or die ("Unable to connect to Localhost");
mysqli_select_db($db,"myweb") or die ("Could not select the database.");


?>