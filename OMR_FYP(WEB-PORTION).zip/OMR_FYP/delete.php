
<?php
extract($_REQUEST);
include('db.php');

$sql=mysqli_query($db,"select * from upload where id='$del'");
$row=mysqli_fetch_array($db,$sql);

unlink("files/$row[name]");

mysqli_query($db,"delete from upload where id='$del'");

header("Location:index.html");

?>