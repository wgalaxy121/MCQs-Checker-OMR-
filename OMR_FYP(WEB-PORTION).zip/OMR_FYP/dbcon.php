<?php
mysqli_select_db(mysqli_connect('localhost','root',''),'myweb')or die(mysqli_error(mysqli_connect('localhost','root','')));
?>